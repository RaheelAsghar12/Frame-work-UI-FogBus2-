package com.example.ossd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
